document.addEventListener('DOMContentLoaded', () => {
    const micBtn = document.getElementById('micBtn');
    const answerText = document.getElementById('answerText');
    const nextBtn = document.getElementById('nextBtn');
    const questionContainer = document.getElementById('questionContainer');
    const studentVideo = document.getElementById('studentVideo');

    let isRecording = false;
    let recognition;
    let currentQuestionIndex = 0;
    const questionsAndAnswers = [];

    // Mock AI-generated questions
    const mockQuestions = [
        "Tell me about yourself.",
        "What are your strengths and weaknesses?",
        "Where do you see yourself in 5 years?",
        "Why should we hire you?",
        "Do you have any questions for us?"
    ];

    function setupSpeechRecognition() {
        window.SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        recognition = new window.SpeechRecognition();
        recognition.continuous = true;
        recognition.interimResults = true;

        recognition.onresult = (event) => {
            const result = event.results[event.results.length - 1];
            const transcript = result[0].transcript;
            answerText.value = transcript;
        };

        recognition.onend = () => {
            isRecording = false;
            micBtn.style.backgroundColor = '#e74c3c';
        };
    }

    function startVideoStream() {
        navigator.mediaDevices.getUserMedia({ video: true })
            .then(stream => {
                studentVideo.srcObject = stream;
            })
            .catch(error => {
                console.error("Error accessing the camera:", error);
            });
    }

    function displayQuestion(index) {
        questionContainer.innerHTML = `<h3>Question ${index + 1}:</h3><p>${mockQuestions[index]}</p>`;
    }

    micBtn.addEventListener('click', () => {
        if (!recognition) {
            setupSpeechRecognition();
        }

        if (isRecording) {
            recognition.stop();
            isRecording = false;
            micBtn.style.backgroundColor = '#e74c3c';
        } else {
            recognition.start();
            isRecording = true;
            micBtn.style.backgroundColor = '#27ae60';
            answerText.value = '';
        }
    });

    nextBtn.addEventListener('click', () => {
        if (currentQuestionIndex < mockQuestions.length - 1) {
            questionsAndAnswers.push({
                question: mockQuestions[currentQuestionIndex],
                answer: answerText.value
            });

            currentQuestionIndex++;
            displayQuestion(currentQuestionIndex);
            answerText.value = '';
            nextBtn.disabled = true;
        } else {
            alert("Interview completed! Thank you for your participation.");
            // Here you would typically send the questionsAndAnswers to your backend
            console.log(questionsAndAnswers);
        }
    });

    answerText.addEventListener('input', () => {
        nextBtn.disabled = answerText.value.trim() === '';
    });

    // Initialize
    startVideoStream();
    displayQuestion(currentQuestionIndex);
    setupSpeechRecognition();
});

